/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'pt-br', {
	title: 'Matemática em TeX',
	button: 'Matemática',
	dialogInput: 'Escreva seu TeX aqui',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'Documentação TeX',
	loading: 'carregando...',
	pathName: 'Matemática'
} );
