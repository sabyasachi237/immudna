<?php
include_once '../../../config.php';
include_once 'header.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$selectOrders = mysqli_query($conn, "SELECT orders.id AS order_id, orders.user_id, orders.total_products, orders.total_price, orders.method, 
    shippingdetails.*
    FROM orders
    JOIN shippingdetails ON orders.id = shippingdetails.order_id");

?>

<div class="order-management-container">
    <h3 style="text-align: center;">Order Management</h3>

    <div class="order-display">
        <h3 style="text-align: center;">Order List</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>User ID</th>
                    <th>Total Products</th>
                    <th>Total Price</th>
                    <th>Payment Method</th>
                    <th>Shipping First Name</th>
                    <!-- Add other shipping details headers as needed -->
                    <th>Action</th>
                </tr>
            </thead>
            <?php while ($orderRow = mysqli_fetch_assoc($selectOrders)) : ?>
                <tr>
                    <td><?= $orderRow['order_id']; ?></td>
                    <td><?= $orderRow['user_id']; ?></td>
                    <td><?= $orderRow['total_products']; ?></td>
                    <td><?= $orderRow['total_price']; ?></td>
                    <td><?= $orderRow['method']; ?></td>
                    <td><?= $orderRow['shipping_first_name']; ?></td>
                    <!-- Add other shipping details data as needed -->
                    <td>
                        <a href="order-view.php?order_id=<?= $orderRow['order_id']; ?>" class="btn btn-info">
                            View All
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

<?php include 'footer.php'; ?>