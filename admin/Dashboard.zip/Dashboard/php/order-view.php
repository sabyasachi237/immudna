<?php
include_once '../../../config.php';
include_once 'header.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get the order_id from the URL
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : null;

// Fetch order details
$selectOrderDetails = mysqli_query($conn, "SELECT orders.id AS order_id, orders.user_id, orders.total_products, orders.total_price, orders.method, 
    shippingdetails.*
    FROM orders
    JOIN shippingdetails ON orders.id = shippingdetails.order_id
    WHERE orders.id = $order_id");

// Check if there is an error in the SQL query
if (!$selectOrderDetails) {
    die('Error fetching order details: ' . mysqli_error($conn));
}

// Fetch the first row (assuming there is only one row for the specific order_id)
$orderDetails = mysqli_fetch_assoc($selectOrderDetails);

?>

<div class="order-details-container">
    <h3 class="text-center mb-4">Order Details</h3>

    <form class="row g-3">
        <div class="col-md-6">
            <label for="orderId" class="form-label">Order ID</label>
            <input type="text" class="form-control" id="orderId" value="<?= $orderDetails['order_id']; ?>" readonly>
        </div>
        <div class="col-md-6">
            <label for="userId" class="form-label">User ID</label>
            <input type="text" class="form-control" id="userId" value="<?= $orderDetails['user_id']; ?>" readonly>
        </div>
        <div class="col-md-6">
            <label for="totalProducts" class="form-label">Total Products</label>
            <input type="text" class="form-control" id="totalProducts" value="<?= $orderDetails['total_products']; ?>" readonly>
        </div>
        <div class="col-md-6">
            <label for="totalPrice" class="form-label">Total Price</label>
            <input type="text" class="form-control" id="totalPrice" value="<?= $orderDetails['total_price']; ?>" readonly>
        </div>
        <div class="col-md-6">
            <label for="paymentMethod" class="form-label">Payment Method</label>
            <input type="text" class="form-control" id="paymentMethod" value="<?= $orderDetails['method']; ?>" readonly>
        </div>
        <div class="col-md-6">
            <label for="shippingFirstName" class="form-label">Shipping First Name</label>
            <input type="text" class="form-control" id="shippingFirstName" value="<?= $orderDetails['shipping_first_name']; ?>" readonly>
        </div>
        <!-- Add other shipping details as needed -->

        <div class="col-12 mt-4">
            <a href="javascript:history.back()" class="btn btn-primary">Back</a>
        </div>
    </form>
</div>

<?php include 'footer.php'; ?>
